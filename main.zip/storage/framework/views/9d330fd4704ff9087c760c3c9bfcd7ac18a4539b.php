<?php $__env->startSection("title"); ?>
    Login
<?php $__env->stopSection(); ?>

<?php $__env->startSection("body"); ?>
    <a></a>
    <div class="container">
        <form action="/login" method="post">
            <br/><br/>
            <h5 class="header col s12 light">ลงชื่อเข้าใช้</h5>
            <br/>
            <div class="input-field col s12">
                <input id="username" type="text" class="validate" name="username">
                <label for="username">Username</label>
            </div>
            <div class="input-field col s12">
                <input id="password" type="password" class="validate" name="password">
                <label for="password">Password</label>
            </div>
            <br/><br/>
            <button class="waves-effect waves-light btn-large orange">ลงชื่อเข้าใช้</button>
        </form>
    </div>
    <br/>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>