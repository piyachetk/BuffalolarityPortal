<?php $__env->startSection("title"); ?>
    หน้าแรก
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>
<div class="section no-pad-bot" id="index-banner">
    <div class="container">
        <br><br>
        <h1 class="header center orange-text">TUMSO 16th</h1>
        <div class="row center">
            <h5 class="header col s12 light" style="line-height: 45px">การแข่งขันคณิตศาสตร์และวิทยาศาสตร์ระหว่างโรงเรียน <br/>โรงเรียนเตรียมอุดมศึกษา ครั้งที่ 16</h5>
        </div>
        <?php if(Auth::check()): ?>
            <div class="row center">
                <a href="notice/" id="download-button" class="btn-large waves-effect waves-light orange">ดูรายละเอียด</a>
            </div>
        <?php else: ?>
            <div class="row center">
                <a href="register/" id="download-button" class="btn-large waves-effect waves-light orange">ลงทะเบียนเข้าร่วม</a>
                <br/><br/>
                <a href="login/" style="color: #a4aaae; font-size: small">ลงชื่อเข้าใช้</a>
            </div>
        <?php endif; ?>
    </div>
</div>
<div class="container">
    <div class="section">

        <div class="z-depth-1 card-panel" style="max-width:800px;margin: 3rem auto auto;">
            <h5 class="center">ประกาศ</h5>

            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliter enim explicari, quod quaeritur, non potest. Qui ita affectus, beatum esse numquam probabis; Servari enim iustitia nisi a forti viro, nisi a sapiente non potest. Ac tamen hic mallet non dolere. Duo Reges: constructio interrete. Itaque hic ipse iam pridem est reiectus; Qui non moveatur et offensione turpitudinis et comprobatione honestatis? </p>

            <p>Ut aliquid scire se gaudeant? Sed mehercule pergrata mihi oratio tua. Sit enim idem caecus, debilis. Quid ei reliquisti, nisi te, quoquo modo loqueretur, intellegere, quid diceret? Si mala non sunt, iacet omnis ratio Peripateticorum. Memini vero, inquam; Quid igitur dubitamus in tota eius natura quaerere quid sit effectum? </p>
        </div>

        <div class="z-depth-1 card-panel" style="max-width:800px;margin: 3rem auto auto;">
            <h5 class="center">FAQ</h5>

            <p>Quamvis enim depravatae non sint, pravae tamen esse possunt. Etsi ea quidem, quae adhuc dixisti, quamvis ad aetatem recte isto modo dicerentur. Ergo id est convenienter naturae vivere, a natura discedere. Et quidem iure fortasse, sed tamen non gravissimum est testimonium multitudinis. Apud ceteros autem philosophos, qui quaesivit aliquid, tacet; Quae autem natura suae primae institutionis oblita est? </p>

            <p>Nam de isto magna dissensio est. Nonne videmus quanta perturbatio rerum omnium consequatur, quanta confusio? Non enim ipsa genuit hominem, sed accepit a natura inchoatum. Nam ista vestra: Si gravis, brevis; Quid ergo? Haec quo modo conveniant, non sane intellego. Nunc omni virtuti vitium contrario nomine opponitur. Dolor ergo, id est summum malum, metuetur semper, etiamsi non aderit; </p>

            <p>His singulis copiose responderi solet, sed quae perspicua sunt longa esse non debent. Venit enim mihi Platonis in mentem, quem accepimus primum hic disputare solitum; Id enim volumus, id contendimus, ut officii fructus sit ipsum officium. Graecis hoc modicum est: Leonidas, Epaminondas, tres aliqui aut quattuor; Quorum sine causa fieri nihil putandum est. </p>
        </div>

    </div>
    <br><br>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>