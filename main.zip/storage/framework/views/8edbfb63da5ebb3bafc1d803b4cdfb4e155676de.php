<!doctype html>
<html lang="<?php echo e(config('app.locale')); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link type="text/css" rel="stylesheet" href="/css/materialize.min.css"  media="screen,projection"/>
    <link type="text/css" rel="stylesheet" href="/fonts/thsarabunnew.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo $__env->yieldContent('title'); ?> - TUMSO 16th</title>

    <style>
        body {
            display: flex;
            min-height: 100vh;
            flex-direction: column;
        }
        main {
            flex: 1 0 auto;
        }

        strong{
            color: red;
            font-size: small;
        }
    </style>
</head>
<body>
<nav class="pink lighten-2" role="navigation">
    <div class="nav-wrapper container"><a id="logo-container" href="/" class="brand-logo">TUMSO 16th</a>
        <?php if(Auth::check()): ?>
            <ul class="right hide-on-med-and-down">
                <li><a href="logout/">ออกจากระบบ</a></li>
                <li><a href="contact/">ติดต่อสอบถาม</a></li>
            </ul>

            <ul id="nav-mobile" class="side-nav">
                <li><a href="logout/">ออกจากระบบ</a></li>
                <li><a href="contact/">ติดต่อสอบถาม</a></li>
            </ul>
        <?php else: ?>
            <ul class="right hide-on-med-and-down">
                <li><a href="login/">เข้าสู่ระบบ</a></li>
                <li><a href="register/">ลงทะเบียน</a></li>
                <li><a href="contact/">ติดต่อสอบถาม</a></li>
            </ul>

            <ul id="nav-mobile" class="side-nav">
                <li><a href="login/">เข้าสู่ระบบ</a></li>
                <li><a href="register/">ลงทะเบียน</a></li>
                <li><a href="contact/">ติดต่อสอบถาม</a></li>
            </ul>
        <?php endif; ?>
        <a href="#" data-activates="nav-mobile" class="button-collapse"><i class="material-icons">menu</i></a>
    </div>
</nav>

<main class="container">
    <?php echo $__env->yieldContent('content'); ?>
</main>

<footer class="page-footer pink lighten-2">
    <div class="container white-text" style="padding-bottom:1rem;">
        งานกิจกรรมพัฒนาผู้เรียน โรงเรียนเตรียมอุดมศึกษา<br />
        227 ถนนพญาไท แขวงปทุมวัน เขตปทุมวัน กรุงเทพมหานคร 10330<br />
        โทรศัพท์: 02-254-0287 ต่อ 157 | โทรสาร: 02-252-7002 | อีเมล: <a href="<?php echo e('mailto:triam.club@gmail.com'); ?>"><?php echo e('triam.club@gmail.com'); ?></a><br />
    </div>
    <div class="footer-copyright">
        <div class="container">
            <span class="hide-on-print">โรงเรียนเตรียมอุดมศึกษา |</span>
            <span class="hide-on-screen">งานกิจกรรมพัฒนาผู้เรียน</span>
        </div>
    </div>
</footer>

<script src="<?php echo e(asset('js/app.js')); ?>"></script>
<script type="text/javascript" src="/js/jquery-3.2.1.min.js"></script>
<script type="text/javascript" src="/js/materialize.min.js"></script>
<script>
    $(document).ready(function(){
        $(".button-collapse").sideNav();});
</script>
</body>
</html>