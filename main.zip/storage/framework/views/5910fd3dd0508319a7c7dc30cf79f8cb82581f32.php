<?php $__env->startSection("title"); ?>
    Projects
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php $__currentLoopData = App\Project::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card large" style="max-width: 960px; width: 100%">
        <div class="card-image waves-effect waves-block waves-light">
            <a href="<?php echo e($project->id); ?>/"><img class="activator" src="/<?php echo e($project->small_logo); ?>"></a>
        </div>
        <div class="card-content">
            <span class="card-title activator grey-text text-darken-4"><?php echo e($project->name); ?></span>
            <p><?php echo e($project->short_description); ?></p>
        </div>
        <div class="card-action">
            <a href="<?php echo e($project->id); ?>/">Details</a>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <!--div class="card large" style="max-width: 960px; width: 100%">
        <div class="card-image waves-effect waves-block waves-light">
            <a href="buftaku-subtitle-utility/"><img class="activator" src="/img/buftaku-subtitle-utility.png"></a>
        </div>
        <div class="card-content">
            <span class="card-title activator grey-text text-darken-4">Buftaku Subtitle Utility</span>
            <p>Buftaku Subtitle Utility เป็นแอปสำหรับ Android สำหรับแก้ไขและสร้างไฟล์ซับไตเติ้ลแบบ Advanced SubStationAlpha (.ass)</p>
        </div>
        <div class="card-action">
            <a href="buftaku-subtitle-utility/">Details</a>
        </div>
    </div>

    <div class="card large" style="max-width: 960px; width: 100%">
        <div class="card-image waves-effect waves-block waves-light">
            <a href="buftaku/"><img class="activator" src="/img/buftaku.png"></a>
        </div>
        <div class="card-content">
            <span class="card-title activator grey-text text-darken-4">Buftaku</span>
            <p>Buftaku เป็นแหล่งรวมเนื้อหาที่ไร้สาระ แปลมังงะและทำซับอนิเมะ</p>
        </div>
        <div class="card-action">
            <a href="buftaku/">Details</a>
        </div>
    </div-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>